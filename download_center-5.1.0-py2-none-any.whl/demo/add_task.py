# -*- coding: utf-8 -*-
"""
Created on 2017/11/17 11:33

@author: zhangle
"""
from buildin_sites.task.task import TaskProcessor
from buildin_sites.task.task import Task
import sys
reload(sys)
sys.setdefaultencoding('utf8')


class AddTask(TaskProcessor):

    def get_user_password(self):
        """
        系统分配的user，password
        :return:
        """
        return 'system', 'system'

    def add_task(self):
        """
        添加任务
        """
        task = Task(host='123.206.214.163', user='zhangle', password='ZhangLe@0910', site=2)
        self.task_queue.put(task)

    def deal_task_results(self, task, results):
        """
        任务添加结果处理
        :param task:
        :param results:
        :return:
        """
        if results == -1:
            print '任务添加失败'
        else:
            print '任务添加成功'


if __name__ == '__main__':
    add_task = AddTask()
    add_task.run()
