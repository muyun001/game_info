# -*- coding: utf8 -*-

# 健康数据库
HEALTH_DB = {
    'host': '182.254.155.218',
    'user': 'health',
    'password': 'healthdb@wd',
    'db': 'health'
}
