# -*- coding: utf-8 -*-
"""
Created on Sun Sep 18 11:12:13 2016

@author: zzm
"""

import os
import sys
import random

# PROJECT_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# sys.path.append(PROJECT_PATH)
# from demo.extractor.demo_extractor import DemoExtractor
# from demo.store.demo_store import DemoStore

from download_center.new_spider.downloader.downloader import SpiderRequest
from download_center.new_spider.spider.basespider import BaseSpider
from download_center.util.util_log import UtilLogger

# PROJECT_PATH = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# sys.path.append(os.path.join(PROJECT_PATH, 'demo'))

# 线下测试
PROJECT_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(PROJECT_PATH)
# 线上测试
# PROJECT_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# sys.path.append(PROJECT_PATH)
# sys.path.append(os.path.join(PROJECT_PATH, 'demo'))

import time
import base64

reload(sys)
sys.setdefaultencoding('utf8')


class DemoSpider(BaseSpider):
    def __init__(self, remote=True):
        super(DemoSpider, self).__init__(remote=remote)
        self.log = UtilLogger('DemoSpider', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'log_demo_spider'))
        self.seed_url = "https://www.baidu.com/s?wd=%s"
        self.upper_limit = 2000

    def get_user_password(self):
        return 'test', 'test'

    def start_requests(self):
        # while True:
        try:
            self.log.info('开始获取初始请求...')
            for i in range(10):
                url = self.seed_url % str(i + 20)
                urls = [{'url': url, 'type': 1, 'unique_key': str(self.get_unique_key()), "test": "test"}]
                # configs = {'store_type': 5}
                ua = random.choice(self.pc_user_agents)
                # , config={"conf_district_id": 3}
                request = SpiderRequest(headers={"User-Agent": ua}, urls=urls, config={"conf_district_id": 3})
                self.sending_queue.put(request)
            time.sleep(8)
        except Exception, e:
            self.log.error('获取初始请求出错:%s' % str(e))

    def get_stores(self):
        stores = list()
        return stores

    def deal_response_results_status(self, task_status, url, result, request):
        if task_status == '2':
            self.log.info('抓取成功:%s' % url)
            self.log.info('ip: {}'.format(result.get("inter_pro", "127.0.0.1")))
            # time.sleep(random.random()*2)

            # capture
            r_l = result["result"].split("||||")
            r_capture = r_l[0]
            with open("test.jpg", "wb") as f:
                f.write(base64.b64decode(r_capture))

        else:
            self.log.info('抓取失败:%s' % url)


def main():
    spider = DemoSpider(remote=False)
    # spider.run(send_num=1, get_num=1, deal_num=1, store_num=1,send_idle_time=600, get_idle_time=600, deal_idle_time=600, store_idle_time=600, record_log=False)
    spider.run(1, 1, 1, 1, record_log=True)


if __name__ == '__main__':
    main()
